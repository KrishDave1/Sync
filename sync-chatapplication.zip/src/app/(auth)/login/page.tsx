/** @format */

"use client";

import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/use-toast";
import { signIn } from "next-auth/react";
import { FC } from "react";
import Image from "next/image";

interface PageProps {}

const Login: FC<PageProps> = ({}) => {
  const { toast } = useToast();

  const loginWithGoogle = async () => {
    try {
      await signIn("google");
    } catch (error) {
      toast({
        title: "Sign-In Error",
        description: "An error occurred while signing in. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className='min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-100 to-purple-200'>
      <div className='bg-white shadow-xl rounded-lg p-8 w-full max-w-md'>
        <div className='text-center mb-8'>
          <Image
            src='/favicon.ico' // Replace with your logo path
            alt='Sync Logo'
            width={100}
            height={100}
            className='mx-auto'
          />
          <h1 className='text-3xl font-bold text-indigo-800 mt-4'>
            Welcome to <span className='text-purple-600'>Sync</span>
          </h1>
          <p className='text-gray-600 mt-2'>Sign in to continue</p>
        </div>
        <Button
          className='w-full flex items-center justify-center bg-indigo-700 text-white hover:bg-indigo-800 transition duration-300 font-semibold py-3 rounded-lg shadow-md'
          onClick={loginWithGoogle}
        >
          <svg
            className='mr-2 h-5 w-5'
            aria-hidden='true'
            focusable='false'
            xmlns='http://www.w3.org/2000/svg'
            viewBox='0 0 24 24'
          >
            <path
              d='M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z'
              fill='#4285F4'
            />
            <path
              d='M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z'
              fill='#34A853'
            />
            <path
              d='M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z'
              fill='#FBBC05'
            />
            <path
              d='M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z'
              fill='#EA4335'
            />
            <path d='M1 1h22v22H1z' fill='none' />
          </svg>
          Continue with Google
        </Button>
        <div className='mt-6 text-center text-gray-600'>
          Don’t have an account?{" "}
          <a
            href='/register'
            className='text-indigo-700 font-semibold hover:underline'
          >
            Sign up
          </a>
        </div>
      </div>
    </div>
  );
};

export default Login;
